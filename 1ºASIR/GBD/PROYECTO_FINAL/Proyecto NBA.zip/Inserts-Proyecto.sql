/*Inserts Proyecto NBA*/

/*Tabla agente_libre*/
INSERT INTO `agente_libre` (`nombre`) VALUES
('Anthony Davis'),
('Ja Morant'),
('Kevin Durant'),
('Lamelo Ball'),
('Lance Stephenson'),
('Luka Doncic'),
('Marc Gasol');

/*Tabla campeon*/
INSERT INTO `campeon` (`año_playoffs`, `este`, `oeste`, `nba`) VALUES
(2020, 'Miami Heat', 'Lakers', 'Lakers'),
(2021, 'Celtics', 'Warriors', 'Warriors');

/*Tabla clasificacion*/
INSERT INTO `clasificacion` (`equip_clas`, `posicion`, `playoffs`) VALUES
('Warriors', 1, 2019),
('Lakers', 1, 2020),
('Celtics', 1, 2021),
('Celtics', 2, 2018),
('Warriors', 2, 2018),
('Celtics', 3, 2020),
('Celtics', 4, 2019),
('Pelicans', 4, 2021),
('Miami Heat', 5, 2020),
('Miami Heat', 6, 2018),
('Pelicans', 6, 2018),
('Miami Heat', 6, 2021),
('Lakers', 10, 2019),
('Miami Heat', 10, 2019),
('Chicago Bulls', 10, 2021),
('Warriors', 10, 2021),
('Lakers', 11, 2018),
('Chicago Bulls', 11, 2020),
('Lakers', 12, 2021),
('Chicago Bulls', 13, 2018),
('Chicago Bulls', 13, 2019),
('Pelicans', 13, 2019),
('Pelicans', 13, 2020),
('Warriors', 15, 2020);

/*Tabla contratos*/
INSERT INTO `contratos` (`dinero`, `años_ofr`, `nombre_jug`) VALUES
(16, 1, 'Derrick White'),
(50, 2, 'Zion Williamson'),
(89, 3, 'Stephen Curry'),
(100, 4, 'Demar Derozan'),
(138, 4, 'Lebron James');

/*Tabla dueño*/
INSERT INTO `dueño` (`nombre`, `patrimonio`) VALUES
('Celtics Partners', 8000),
('Gayle Benson', 4700),
('Jerry Reinsdorf', 1800),
('Joe Lacob', 1500),
('Magic Johnson', 620),
('Micky Arison', 5700);

/*Tabla equipos*/
INSERT INTO `equipos` (`nombre`, `dors_reti`, `campeonatos`, `fech_fund`, `clasificacion`) VALUES
('Celtics', '5,6,33,34', 17, 1946, 3),
('Chicago Bulls', '23,33,91', 6, 1966, 13),
('Lakers', '8,24,32,33,34', 17, 1947, 1),
('Miami Heat', '1,3,32', 3, 1988, 5),
('Pelicans', NULL, NULL, 1988, 13),
('Warriors', '13,14,24', 7, 1946, 15);

/*Tabla este*/
INSERT INTO `este` (`nombre_este`, `año_este`, `clasi`) VALUES
('Celtics', 2020, 3),
('Miami Heat', 2020, 5),
('Chicago Bulls', 2020, 11);

/*Tabla jugadores*/
INSERT INTO `jugadores` (`nombre`, `años`, `posicion`, `dorsal`, `contrato`) VALUES
('Anthony Davis', 29, 'Ala-Pivot', 3, NULL),
('Demar Derozan', 33, 'Alero', 11, 100),
('Derrick White', 28, 'Escolta', 9, 16),
('Ja Morant', 23, 'Base', 12, NULL),
('Kevin Durant', 34, 'Alero', 7, NULL),
('Lamelo Ball', 21, 'Base', 1, NULL),
('Lance Stephenson', 34, 'Base', 6, NULL),
('Lebron James', 38, 'Alero', 6, 138),
('Luka Doncic', 24, 'Base', 77, NULL),
('Marc Gasol', 36, 'Pivot', 33, NULL),
('Stephen Curry', 34, 'Base', 30, 89),
('Zion Williamson', 22, 'Ala-Pivot', 1, 50);

/*Tabla jugadores_nac*/
INSERT INTO `jugadores_nac` (`nacionalidad`, `nombre`) VALUES
('EEUU', 'Anthony Davis'),
('EEUU', 'Demar Derozan'),
('EEUU', 'Derrick White'),
('EEUU', 'Ja Morant'),
('EEUU', 'Kevin Durant'),
('EEUU', 'Lamelo Ball'),
('EEUU', 'Lance Stephenson'),
('EEUU', 'Lebron James'),
('EEUU', 'Stephen Curry'),
('EEUU', 'Zion Williamson'),
('Eslovenia', 'Luka Doncic'),
('España', 'Marc Gasol');

/*Tabla jugador_con_contrato*/
INSERT INTO `jugador_con_contrato` (`nombre`) VALUES
('Demar Derozan'),
('Derrick White'),
('Lebron James'),
('Stephen Curry'),
('Zion Williamson');

/*Tabla oeste*/
INSERT INTO `oeste` (`nombre_oeste`, `año_oeste`, `clasi`) VALUES
('Lakers', 2020, 1),
('Pelicans', 2020, 13),
('Warriors', 2020, 15);

/*Tabla ofrecer*/
INSERT INTO `ofrecer` (`contrato`, `equipo`) VALUES
(16, 'Celtics'),
(50, 'Pelicans'),
(89, 'Warriors'),
(100, 'Chicago Bulls'),
(138, 'Lakers');

/*Tabla partidos*/
INSERT INTO `partidos` (`temp_regular`, `jugador`, `equipo`, `part_jug`) VALUES
(2020, 'Demar Derozan', 'Chicago Bulls', 54),
(2020, 'Derrick White', 'Celtics', 35),
(2020, 'Lebron James', 'Lakers', 65),
(2020, 'Stephen Curry', 'Warriors', 50);

/*Tabla playoffs*/
INSERT INTO `playoffs` (`año`) VALUES
(2018),
(2019),
(2020),
(2021);

/*Tabla temporada_regular*/
INSERT INTO `temporada_regular` (`name_equip`, `num_temp`, `victorias`, `derrotas`, `posicion`) VALUES
('Celtics', 2020, 48, 24, 3),
('Chicago Bulls', 2020, 22, 43, 11),
('Lakers', 2020, 52, 19, 1),
('Miami Heat', 2020, 44, 29, 5),
('Pelicans', 2020, 30, 42, 13),
('Warriors', 2020, 15, 50, 15);

/*Tabla tiene*/
INSERT INTO `tiene` (`dueño`, `equipo`, `fech_adq`) VALUES
('Celtics Partners', 'Celtics', 1989),
('Gayle Benson', 'Pelicans', 2018),
('Jerry Reinsdorf', 'Chicago Bulls', 1985),
('Joe Lacob', 'Warriors', 2010),
('Magic Johnson', 'Lakers', 1995),
('Micky Arison', 'Miami Heat', 1995);

