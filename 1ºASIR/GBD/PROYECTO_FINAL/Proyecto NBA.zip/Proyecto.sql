-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 07-03-2023 a las 09:45:54
-- Versión del servidor: 10.4.27-MariaDB
-- Versión de PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `proyecto`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `agente_libre`
--

CREATE TABLE `agente_libre` (
  `nombre` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `agente_libre`
--

INSERT INTO `agente_libre` (`nombre`) VALUES
('Anthony Davis'),
('Ja Morant'),
('Kevin Durant'),
('Lamelo Ball'),
('Lance Stephenson'),
('Luka Doncic'),
('Marc Gasol');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `campeon`
--

CREATE TABLE `campeon` (
  `año_playoffs` int(11) NOT NULL,
  `este` varchar(20) NOT NULL,
  `oeste` varchar(20) NOT NULL,
  `nba` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `campeon`
--

INSERT INTO `campeon` (`año_playoffs`, `este`, `oeste`, `nba`) VALUES
(2020, 'Miami Heat', 'Lakers', 'Lakers'),
(2021, 'Celtics', 'Warriors', 'Warriors');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clasificacion`
--

CREATE TABLE `clasificacion` (
  `equip_clas` varchar(20) NOT NULL,
  `posicion` int(11) NOT NULL,
  `playoffs` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clasificacion`
--

INSERT INTO `clasificacion` (`equip_clas`, `posicion`, `playoffs`) VALUES
('Warriors', 1, 2019),
('Lakers', 1, 2020),
('Celtics', 1, 2021),
('Celtics', 2, 2018),
('Warriors', 2, 2018),
('Celtics', 3, 2020),
('Celtics', 4, 2019),
('Pelicans', 4, 2021),
('Miami Heat', 5, 2020),
('Miami Heat', 6, 2018),
('Pelicans', 6, 2018),
('Miami Heat', 6, 2021),
('Lakers', 10, 2019),
('Miami Heat', 10, 2019),
('Chicago Bulls', 10, 2021),
('Warriors', 10, 2021),
('Lakers', 11, 2018),
('Chicago Bulls', 11, 2020),
('Lakers', 12, 2021),
('Chicago Bulls', 13, 2018),
('Chicago Bulls', 13, 2019),
('Pelicans', 13, 2019),
('Pelicans', 13, 2020),
('Warriors', 15, 2020);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contratos`
--

CREATE TABLE `contratos` (
  `dinero` int(11) NOT NULL,
  `años_ofr` int(11) DEFAULT NULL,
  `nombre_jug` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `contratos`
--

INSERT INTO `contratos` (`dinero`, `años_ofr`, `nombre_jug`) VALUES
(16, 1, 'Derrick White'),
(50, 2, 'Zion Williamson'),
(89, 3, 'Stephen Curry'),
(100, 4, 'Demar Derozan'),
(138, 4, 'Lebron James');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dueño`
--

CREATE TABLE `dueño` (
  `nombre` varchar(20) NOT NULL,
  `patrimonio` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `dueño`
--

INSERT INTO `dueño` (`nombre`, `patrimonio`) VALUES
('Celtics Partners', 8000),
('Gayle Benson', 4700),
('Jerry Reinsdorf', 1800),
('Joe Lacob', 1500),
('Magic Johnson', 620),
('Micky Arison', 5700);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `equipos`
--

CREATE TABLE `equipos` (
  `nombre` varchar(20) NOT NULL,
  `dors_reti` varchar(30) DEFAULT NULL,
  `campeonatos` int(11) DEFAULT NULL,
  `fech_fund` int(11) DEFAULT NULL,
  `clasificacion` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `equipos`
--

INSERT INTO `equipos` (`nombre`, `dors_reti`, `campeonatos`, `fech_fund`, `clasificacion`) VALUES
('Celtics', '5,6,33,34', 17, 1946, 3),
('Chicago Bulls', '23,33,91', 6, 1966, 13),
('Lakers', '8,24,32,33,34', 17, 1947, 1),
('Miami Heat', '1,3,32', 3, 1988, 5),
('Pelicans', NULL, NULL, 1988, 13),
('Warriors', '13,14,24', 7, 1946, 15);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `este`
--

CREATE TABLE `este` (
  `nombre_este` varchar(20) NOT NULL,
  `año_este` int(11) NOT NULL,
  `clasi` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `este`
--

INSERT INTO `este` (`nombre_este`, `año_este`, `clasi`) VALUES
('Celtics', 2020, 3),
('Miami Heat', 2020, 5),
('Chicago Bulls', 2020, 11);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jugadores`
--

CREATE TABLE `jugadores` (
  `nombre` varchar(20) NOT NULL,
  `años` int(11) DEFAULT NULL,
  `posicion` varchar(20) DEFAULT NULL,
  `dorsal` int(11) DEFAULT NULL,
  `contrato` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `jugadores`
--

INSERT INTO `jugadores` (`nombre`, `años`, `posicion`, `dorsal`, `contrato`) VALUES
('Anthony Davis', 29, 'Ala-Pivot', 3, NULL),
('Demar Derozan', 33, 'Alero', 11, 100),
('Derrick White', 28, 'Escolta', 9, 16),
('Ja Morant', 23, 'Base', 12, NULL),
('Kevin Durant', 34, 'Alero', 7, NULL),
('Lamelo Ball', 21, 'Base', 1, NULL),
('Lance Stephenson', 34, 'Base', 6, NULL),
('Lebron James', 38, 'Alero', 6, 138),
('Luka Doncic', 24, 'Base', 77, NULL),
('Marc Gasol', 36, 'Pivot', 33, NULL),
('Stephen Curry', 34, 'Base', 30, 89),
('Zion Williamson', 22, 'Ala-Pivot', 1, 50);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jugadores_nac`
--

CREATE TABLE `jugadores_nac` (
  `nacionalidad` varchar(20) NOT NULL,
  `nombre` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `jugadores_nac`
--

INSERT INTO `jugadores_nac` (`nacionalidad`, `nombre`) VALUES
('EEUU', 'Anthony Davis'),
('EEUU', 'Demar Derozan'),
('EEUU', 'Derrick White'),
('EEUU', 'Ja Morant'),
('EEUU', 'Kevin Durant'),
('EEUU', 'Lamelo Ball'),
('EEUU', 'Lance Stephenson'),
('EEUU', 'Lebron James'),
('EEUU', 'Stephen Curry'),
('EEUU', 'Zion Williamson'),
('Eslovenia', 'Luka Doncic'),
('España', 'Marc Gasol');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jugador_con_contrato`
--

CREATE TABLE `jugador_con_contrato` (
  `nombre` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `jugador_con_contrato`
--

INSERT INTO `jugador_con_contrato` (`nombre`) VALUES
('Demar Derozan'),
('Derrick White'),
('Lebron James'),
('Stephen Curry'),
('Zion Williamson');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `oeste`
--

CREATE TABLE `oeste` (
  `nombre_oeste` varchar(20) NOT NULL,
  `año_oeste` int(11) NOT NULL,
  `clasi` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `oeste`
--

INSERT INTO `oeste` (`nombre_oeste`, `año_oeste`, `clasi`) VALUES
('Lakers', 2020, 1),
('Pelicans', 2020, 13),
('Warriors', 2020, 15);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ofrecer`
--

CREATE TABLE `ofrecer` (
  `contrato` int(11) NOT NULL,
  `equipo` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ofrecer`
--

INSERT INTO `ofrecer` (`contrato`, `equipo`) VALUES
(16, 'Celtics'),
(50, 'Pelicans'),
(89, 'Warriors'),
(100, 'Chicago Bulls'),
(138, 'Lakers');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `partidos`
--

CREATE TABLE `partidos` (
  `temp_regular` int(11) NOT NULL,
  `jugador` varchar(20) NOT NULL,
  `equipo` varchar(20) NOT NULL,
  `part_jug` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `partidos`
--

INSERT INTO `partidos` (`temp_regular`, `jugador`, `equipo`, `part_jug`) VALUES
(2020, 'Demar Derozan', 'Chicago Bulls', 54),
(2020, 'Derrick White', 'Celtics', 35),
(2020, 'Lebron James', 'Lakers', 65),
(2020, 'Stephen Curry', 'Warriors', 50);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `playoffs`
--

CREATE TABLE `playoffs` (
  `año` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `playoffs`
--

INSERT INTO `playoffs` (`año`) VALUES
(2018),
(2019),
(2020),
(2021);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `temporada_regular`
--

CREATE TABLE `temporada_regular` (
  `name_equip` varchar(20) NOT NULL,
  `num_temp` int(11) NOT NULL,
  `victorias` int(11) DEFAULT NULL,
  `derrotas` int(11) DEFAULT NULL,
  `posicion` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `temporada_regular`
--

INSERT INTO `temporada_regular` (`name_equip`, `num_temp`, `victorias`, `derrotas`, `posicion`) VALUES
('Celtics', 2020, 48, 24, 3),
('Chicago Bulls', 2020, 22, 43, 11),
('Lakers', 2020, 52, 19, 1),
('Miami Heat', 2020, 44, 29, 5),
('Pelicans', 2020, 30, 42, 13),
('Warriors', 2020, 15, 50, 15);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tiene`
--

CREATE TABLE `tiene` (
  `dueño` varchar(20) NOT NULL,
  `equipo` varchar(20) DEFAULT NULL,
  `fech_adq` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tiene`
--

INSERT INTO `tiene` (`dueño`, `equipo`, `fech_adq`) VALUES
('Celtics Partners', 'Celtics', 1989),
('Gayle Benson', 'Pelicans', 2018),
('Jerry Reinsdorf', 'Chicago Bulls', 1985),
('Joe Lacob', 'Warriors', 2010),
('Magic Johnson', 'Lakers', 1995),
('Micky Arison', 'Miami Heat', 1995);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `agente_libre`
--
ALTER TABLE `agente_libre`
  ADD PRIMARY KEY (`nombre`);

--
-- Indices de la tabla `campeon`
--
ALTER TABLE `campeon`
  ADD PRIMARY KEY (`año_playoffs`,`nba`,`este`,`oeste`);

--
-- Indices de la tabla `clasificacion`
--
ALTER TABLE `clasificacion`
  ADD PRIMARY KEY (`posicion`,`playoffs`,`equip_clas`) USING BTREE,
  ADD KEY `fk_clasificacion` (`playoffs`),
  ADD KEY `fk_equip_clas` (`equip_clas`);

--
-- Indices de la tabla `contratos`
--
ALTER TABLE `contratos`
  ADD PRIMARY KEY (`dinero`),
  ADD KEY `fk_contratos_nombre_jugador` (`nombre_jug`);

--
-- Indices de la tabla `dueño`
--
ALTER TABLE `dueño`
  ADD PRIMARY KEY (`nombre`);

--
-- Indices de la tabla `equipos`
--
ALTER TABLE `equipos`
  ADD PRIMARY KEY (`nombre`),
  ADD KEY `fk_equipos_clasi` (`clasificacion`);

--
-- Indices de la tabla `este`
--
ALTER TABLE `este`
  ADD PRIMARY KEY (`clasi`,`año_este`,`nombre_este`),
  ADD KEY `fk_nombre_este` (`nombre_este`),
  ADD KEY `fk_año_este` (`año_este`);

--
-- Indices de la tabla `jugadores`
--
ALTER TABLE `jugadores`
  ADD PRIMARY KEY (`nombre`),
  ADD KEY `fk_jugadores` (`contrato`);

--
-- Indices de la tabla `jugadores_nac`
--
ALTER TABLE `jugadores_nac`
  ADD PRIMARY KEY (`nacionalidad`,`nombre`),
  ADD KEY `fk_jugadores_nac` (`nombre`);

--
-- Indices de la tabla `jugador_con_contrato`
--
ALTER TABLE `jugador_con_contrato`
  ADD PRIMARY KEY (`nombre`);

--
-- Indices de la tabla `oeste`
--
ALTER TABLE `oeste`
  ADD PRIMARY KEY (`clasi`,`año_oeste`,`nombre_oeste`),
  ADD KEY `fk_nombre_oeste` (`nombre_oeste`),
  ADD KEY `fk_año_oeste` (`año_oeste`);

--
-- Indices de la tabla `ofrecer`
--
ALTER TABLE `ofrecer`
  ADD PRIMARY KEY (`contrato`,`equipo`),
  ADD KEY `fk_ofrecer_equipo` (`equipo`);

--
-- Indices de la tabla `partidos`
--
ALTER TABLE `partidos`
  ADD PRIMARY KEY (`temp_regular`,`jugador`),
  ADD KEY `fk_partidos_jugador` (`jugador`),
  ADD KEY `fk_partidos_equipo` (`equipo`);

--
-- Indices de la tabla `playoffs`
--
ALTER TABLE `playoffs`
  ADD PRIMARY KEY (`año`);

--
-- Indices de la tabla `temporada_regular`
--
ALTER TABLE `temporada_regular`
  ADD PRIMARY KEY (`num_temp`,`name_equip`),
  ADD KEY `fk_name_equip` (`name_equip`);

--
-- Indices de la tabla `tiene`
--
ALTER TABLE `tiene`
  ADD PRIMARY KEY (`dueño`),
  ADD KEY `fk_tiene_equipo` (`equipo`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `agente_libre`
--
ALTER TABLE `agente_libre`
  ADD CONSTRAINT `fk_agente_libre` FOREIGN KEY (`nombre`) REFERENCES `jugadores` (`nombre`);

--
-- Filtros para la tabla `campeon`
--
ALTER TABLE `campeon`
  ADD CONSTRAINT `fk_campeon` FOREIGN KEY (`año_playoffs`) REFERENCES `playoffs` (`año`);

--
-- Filtros para la tabla `clasificacion`
--
ALTER TABLE `clasificacion`
  ADD CONSTRAINT `fk_clasificacion` FOREIGN KEY (`playoffs`) REFERENCES `playoffs` (`año`),
  ADD CONSTRAINT `fk_equip_clas` FOREIGN KEY (`equip_clas`) REFERENCES `equipos` (`nombre`);

--
-- Filtros para la tabla `contratos`
--
ALTER TABLE `contratos`
  ADD CONSTRAINT `fk_contratos_nombre_jugador` FOREIGN KEY (`nombre_jug`) REFERENCES `jugadores` (`nombre`);

--
-- Filtros para la tabla `equipos`
--
ALTER TABLE `equipos`
  ADD CONSTRAINT `fk_equipos_clasi` FOREIGN KEY (`clasificacion`) REFERENCES `clasificacion` (`posicion`);

--
-- Filtros para la tabla `este`
--
ALTER TABLE `este`
  ADD CONSTRAINT `fk_año_este` FOREIGN KEY (`año_este`) REFERENCES `playoffs` (`año`),
  ADD CONSTRAINT `fk_nombre_este` FOREIGN KEY (`nombre_este`) REFERENCES `equipos` (`nombre`);

--
-- Filtros para la tabla `jugadores`
--
ALTER TABLE `jugadores`
  ADD CONSTRAINT `fk_jugadores` FOREIGN KEY (`contrato`) REFERENCES `contratos` (`dinero`);

--
-- Filtros para la tabla `jugadores_nac`
--
ALTER TABLE `jugadores_nac`
  ADD CONSTRAINT `fk_jugadores_nac` FOREIGN KEY (`nombre`) REFERENCES `jugadores` (`nombre`);

--
-- Filtros para la tabla `jugador_con_contrato`
--
ALTER TABLE `jugador_con_contrato`
  ADD CONSTRAINT `fk_jugador_con_contrato` FOREIGN KEY (`nombre`) REFERENCES `jugadores` (`nombre`);

--
-- Filtros para la tabla `oeste`
--
ALTER TABLE `oeste`
  ADD CONSTRAINT `fk_año_oeste` FOREIGN KEY (`año_oeste`) REFERENCES `playoffs` (`año`),
  ADD CONSTRAINT `fk_nombre_oeste` FOREIGN KEY (`nombre_oeste`) REFERENCES `equipos` (`nombre`);

--
-- Filtros para la tabla `ofrecer`
--
ALTER TABLE `ofrecer`
  ADD CONSTRAINT `fk_ofrecer_contrato` FOREIGN KEY (`contrato`) REFERENCES `contratos` (`dinero`),
  ADD CONSTRAINT `fk_ofrecer_equipo` FOREIGN KEY (`equipo`) REFERENCES `equipos` (`nombre`);

--
-- Filtros para la tabla `partidos`
--
ALTER TABLE `partidos`
  ADD CONSTRAINT `fk_partidos_equipo` FOREIGN KEY (`equipo`) REFERENCES `equipos` (`nombre`),
  ADD CONSTRAINT `fk_partidos_jugador` FOREIGN KEY (`jugador`) REFERENCES `jugadores` (`nombre`);

--
-- Filtros para la tabla `temporada_regular`
--
ALTER TABLE `temporada_regular`
  ADD CONSTRAINT `fk_name_equip` FOREIGN KEY (`name_equip`) REFERENCES `equipos` (`nombre`);

--
-- Filtros para la tabla `tiene`
--
ALTER TABLE `tiene`
  ADD CONSTRAINT `fk_tiene_dueño` FOREIGN KEY (`dueño`) REFERENCES `dueño` (`nombre`),
  ADD CONSTRAINT `fk_tiene_equipo` FOREIGN KEY (`equipo`) REFERENCES `equipos` (`nombre`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
